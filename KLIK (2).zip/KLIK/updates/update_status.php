<?php
session_start();

if (isset($_POST['login-submit'])) {
    require 'dbh.inc.php';

//1. Get the ID of Selected Admin
    $id = $_GET['uidUsers'];

//2. Create SQL Query to Get the Details
    $sql = "SELECT * FROM users WHERE uidUsers=$id";

//Execute the Query
    $res = mysqli_query($conn, $sql);

//Check whether the query is executed or not
    if ($res == true) {
        // Check whether the data is available or not
        $count = mysqli_num_rows($res);
        //Check whether we have admin data or not
        if ($count == 1) {
            // Get the Details
            //echo "Admin Available";
            $row = mysqli_fetch_assoc($res);

            $status = $row['status'];
            $row = "Online";

        } else {
            //Redirect to Manage Admin PAge
            header("Location: ../login.php?error=emptyfields");
        }
    }

    ?>



<?php

//Check whether the Submit Button is Clicked or not
    if (isset($_GET['login-submit'])) {
        //echo "Button CLicked";
        //Get all the values from form to update
        $id = $_GET['uidUsers'];

        //Create a SQL Query to Update Admin
        $sql = "UPDATE users SET
        status = '$status',
        WHERE id='$id'
        ";

        //Execute the Query
        $res = mysqli_query($conn, $sql);

        //Check whether the query executed successfully or not
        if ($res == true) {
            //Query Executed and Admin Updated
            $_SESSION['update'] = "<div class='success'>user Updated Successfully.</div>";
            //Redirect to Manage Admin Page
            header("Location: ../index.php?error=emptyfields");
        } else {
            //Failed to Update Admin
            $_SESSION['update'] = "<div class='error'>Failed to Delete Admin.</div>";
            //Redirect to Manage Admin Page
            header("Location: ../login.php?error=emptyfields");
        }
    }

}