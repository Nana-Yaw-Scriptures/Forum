<?php

    session_start();
    require 'includes/dbh.inc.php';
    define('TITLE',"Forums | COMPSA");
    
    if(!isset($_SESSION['userId']))
    {
        header("Location: login.php");
        exit();
    }
    
    include 'includes/HTML-head.php';
?>


<link rel="stylesheet" type="text/css" href="css/list-page.css">
</head>

<body style="background: #f1f1f1">

    <?php
            
            include 'includes/navbar.php';
        
            if(isset($_GET['cat']))
            {
                $sql = "select * from categories "
                        . "where cat_id = ?";
                
                $stmt = mysqli_stmt_init($conn);  

                if (!mysqli_stmt_prepare($stmt, $sql))
                {
                    die('SQL error');
                }
                else
                {
                    mysqli_stmt_bind_param($stmt, "s", $_GET['cat']);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);

                    $category = mysqli_fetch_assoc($result);
                }
            }
        ?>


    <main role="main" class="container">
        <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded shadow-sm">
            <img class="mr-3" src="img/200.png" alt="" width="48" height="48">
            <div class="lh-100">
                <h1 class="mb-0 text-white lh-100">COMPSA Blogs</h1>
                <small>Spreading Ideas</small>
            </div>
        </div>


        <div class="my-3 p-3 bg-white rounded shadow-sm">
            <h5 class="border-bottom border-gray pb-2 mb-0">
                <?php 
                    if(isset($_GET['cat']))
                    {
                        echo '<a href="blogs.php">Blogs</a>
                        / <span style="color: #709fea ">'.ucwords($category['blog_title'])."</span>";
                    }
                    else
                    {
                        echo 'All Blogs';
                    }
                ?>
            </h5>

            <?php


            $sql = "select blog_id, blog_title, blog_img, blog_by, blog_date, blog_votes, blog_content, userImg, idUsers, uidUsers, (
                            select sum(blog_votes)
                        from blogs
                        where blog_title = blog_id
                        ) as upvotes
                    from blogs, users 
                    where ";
            
            if(isset($_GET['tit']))
            {
                $sql .= "blog_title = " . $_GET['tit'] . " and ";
            }
            
            $sql .= "blogs.blog_by = users.idUsers
                   
                    order by blog_id asc ";
            $stmt = mysqli_stmt_init($conn);  
            
            if (!mysqli_stmt_prepare($stmt, $sql))
            {
                die('SQL error');
            }
            else
            {
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                while ($row = mysqli_fetch_assoc($result))
                {
                  
                    
                    echo '<a href="blog-page.php?id='.$row['blog_id'].'">
                        <div class="media text-muted pt-3">
                            <img src="img/blog-cover.png" alt="" class="mr-2 rounded div-img">
                            <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                              <strong class="d-block text-gray-dark">'.ucwords($row['blog_title']).'</strong></a>
                              <span class="text-warning">'.ucwords($row['uidUsers']).'</span><br><br>
                              '.date("F jS, Y", strtotime($row['blog_date'])).'
                            </p>
                            <span class="text-primary text-center">
                                <i class="fa fa-chevron-up" aria-hidden="true"></i><br>
                                    '.$row['upvotes'].'<br>';
                    
                    if ($_SESSION['userLevel'] == 1 || $_SESSION['userId'] == $row['idUsers'])
                    {
                        echo '<a href="includes/delete-blog.php?id='.$row['blog_id'].'&page=blogs" >
                                <i class="fa fa-trash" aria-hidden="true" style="color: red;"></i>
                              </a>
                            </span>';
                    }
                    else
                    {
                        echo '</span>';
                    }
                    echo '</span>
                            </div>';
                }
           }
        ?>

            <small class="d-block text-right mt-3">
                <a href="create-blog.php" class="btn btn-primary">Create A Blog</a>
            </small>

        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>

</html>