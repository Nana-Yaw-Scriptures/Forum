<?php

$serverName = "localhost";
$dBUsername = "project";
$dBPassword = "good4meyaws";
$dBName = "social_forum";

$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn)
{
    die("Connection failed: ". mysqli_connect_error());
}


