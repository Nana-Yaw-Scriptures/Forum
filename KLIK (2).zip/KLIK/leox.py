import random as rnd
secret_number = rnd.randint(0, 30)
guess_count = 0
guess_limit = 3
while guess_count < guess_limit:
    guess = int(input("Guess: "))
    guess_count += 1
    if guess == secret_number:
        print("You won")
    else:
        print("Sorry, you lost!")
        print(secret_number)
        